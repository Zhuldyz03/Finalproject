package com.company.hospital;

import com.company.patient.Patient;

import java.util.ArrayList;
import java.util.List;

public class Clinic extends HospitalObserver implements HospitalMode {
    private List<Patient> patients;
    private boolean open = true;
    private int room = 2;
    private final static int max = 5;

    public Clinic(String... types) {
        super(types);
        patients = new ArrayList<>();
    }

    public List<Patient> getPatients() {
        return patients;
    }

    public void setPatients(List<Patient> patients) {
        this.patients = patients;
    }

    @Override
    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    public int getRoom() {
        return room;
    }

    public void setRoom(int room) {
        this.room = room;
    }

    @Override
    public void close() {
        open = false;
        System.out.println("Hospital is closed");
    }

    @Override
    public void open() {
        open = true;
        System.out.println("Hospital is open");
    }

    @Override
    public void addRoom() {
        if(room == max) {
            System.out.println("Max number of rooms is " + max);
            return;
        }
        room += 1;
        System.out.println("1 room is added. Capacity of patients: " + 5 * 10);
    }

    @Override
    public void removeRoom() {
        if(room == 1) {
            System.out.println("Number of rooms cannot be less than 1");
            return;
        }
        room -= 1;
        System.out.println("1 room is removed. Capacity of patients: " + room * 10);
    }

    @Override
    public void addClient(Patient patient) {
        patients.add(patient);
    }

    @Override
    public void remove(Patient patient) {
        patients.remove(patient);
    }

    @Override
    public void alert(String personalType) {
        if(open) super.alert(personalType);
        else System.out.println("Hospital is closed");
    }
}
