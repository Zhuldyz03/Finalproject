package com.company.hospital;

public class HospitalController {
    private HospitalMode hospital;

    public HospitalController(Hospital hospital) {
        this.hospital = hospital;
    }

    public HospitalController() {
        Hospital hospital = new Hospital();
    }

    public static void alertAll(HospitalObserver hospitalObserver) {
    }

    public HospitalMode getHospital() {
        return hospital;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }

    public void openClose() {
        if(hospital.isOpen()) {
            hospital.close();
        }
        else {
            hospital.open();
        }
    }

    public void alertAll() {
        for(String type : hospital.getTypes()) {
            hospital.alert(type);
        }
    }

    public void increaseRoom(int n) {
        for(int i = 0; i < n; i++) {
            hospital.addRoom();
        }
    }

    public void decreaseRoom(int n) {
        for(int i = 0; i < n; i++) {
            hospital.removeRoom();
        }
    }
}
