package com.company.hospital;

import com.company.personal.Personal;

import java.util.*;

public abstract class HospitalObserver {
    Map<String, List<Personal>> personals = new HashMap<>();

    public HospitalObserver(String... types) {
        for(String personalType : types) {
            this.personals.put(personalType, new ArrayList<>());
        }
    }

    public Set<String> getTypes() {
        return personals.keySet();
    }

    public HospitalObserver(Map<String, List<Personal>> personals) {
        this.personals = personals;
    }

    public void hire(String personalType, Personal personal) {
        personals.get(personalType).add(personal);
    }

    public void fire(String personalType, Personal personal) {
        personals.get(personalType).remove(personal);
    }

    public void alert(String personalType) {
        List<Personal> temp = personals.get(personalType);
        for(Personal x : temp) {
            x.doWork();
        }
    }
}
