package com.company.hospital;

import com.company.patient.Patient;

import java.util.Set;

public interface HospitalMode {
    boolean isOpen();
    void close();
    void open();
    void addRoom();
    void removeRoom();
    void addClient(Patient patient);
    void remove(Patient patient);
    Set<String> getTypes();
    void alert(String personalType);
}
