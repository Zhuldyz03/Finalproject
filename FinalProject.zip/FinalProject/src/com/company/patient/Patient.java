package com.company.patient;

public class Patient {
    private int id;
    private String fullname = "No name";
    private double temperature = 36.6;
    private int pressure_systolic = 120;
    private int pressure_diastolic = 80;
    private int age = 0;
    private boolean sneeze = false;
    private boolean cough = false;
    private boolean nausea = false;

    private PatientState state;

    public Patient() {
    }

    public Patient(int id, String fullname, double temperature, int pressure_systolic, int pressure_diastolic, int age, boolean sneeze, boolean cough, boolean nausea) {
        this.id = id;
        this.fullname = fullname;
        this.temperature = temperature;
        this.pressure_systolic = pressure_systolic;
        this.pressure_diastolic = pressure_diastolic;
        this.age = age;
        this.sneeze = sneeze;
        this.cough = cough;
        this.nausea = nausea;
        if (temperature < 36) {
            state = new PatientHypothermiaState(this);
        } else if (temperature > 36) {
            state = new PatientHyperthermiaState(this);
        } else {
            state = new PatientNormalState(this);
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
        if (temperature < 36) {
            state = new PatientHypothermiaState(this);
        } else if (temperature > 36) {
            state = new PatientHyperthermiaState(this);
        } else {
            state = new PatientNormalState(this);
        }
    }

    public int getPressure_systolic() {
        return pressure_systolic;
    }

    public void setPressure_systolic(int pressure_systolic) {
        this.pressure_systolic = pressure_systolic;
    }

    public int getPressure_diastolic() {
        return pressure_diastolic;
    }

    public void setPressure_diastolic(int pressure_diastolic) {
        this.pressure_diastolic = pressure_diastolic;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isSneeze() {
        return sneeze;
    }

    public void setSneeze(boolean sneeze) {
        this.sneeze = sneeze;
    }

    public boolean isCough() {
        return cough;
    }

    public void setCough(boolean cough) {
        this.cough = cough;
    }

    public boolean isNausea() {
        return nausea;
    }

    public void setNausea(boolean nausea) {
        this.nausea = nausea;
    }

    public void giveParacetamol() {
        state.giveParacetamol();
    }

    public void giveHotDrink() {
        state.giveHotDrink();
    }
}
