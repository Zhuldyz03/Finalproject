package com.company.patient;

public class PatientHyperthermiaState extends PatientState {
    public PatientHyperthermiaState(Patient patient) {
        super(patient);
    }

    @Override
    public void giveParacetamol() {
        patient.setTemperature(patient.getTemperature() - 1);
        System.out.println("Temperature decreased to 1");
    }

    @Override
    public void giveHotDrink() {
        System.out.println("Nothing happens");
    }
}
