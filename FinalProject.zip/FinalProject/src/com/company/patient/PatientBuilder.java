package com.company.patient;

public class PatientBuilder {
    private Patient patient;

    public PatientBuilder() {
        patient = new Patient();
    }

    public PatientBuilder reset() {
        patient = new Patient();
        return this;
    }

    public PatientBuilder setId(int id) {
        patient.setId(id);
        return this;
    }

    public PatientBuilder setFullName(String fullname) {
        patient.setFullname(fullname);
        return this;
    }

    public PatientBuilder setTemperature(int temperature) {
        patient.setTemperature(temperature);
        return this;
    }

    public PatientBuilder setPressureSystolic(int pressureSystolic) {
        patient.setPressure_systolic(pressureSystolic);
        return this;
    }

    public PatientBuilder setPressureDiastolic(int pressureDiastolic) {
        patient.setPressure_diastolic(pressureDiastolic);
        return this;
    }

    public PatientBuilder setAge(int age) {
        patient.setAge(age);
        return this;
    }

    public PatientBuilder sneeze() {
        patient.setSneeze(true);
        return this;
    }

    public PatientBuilder noSneeze() {
        patient.setSneeze(false);
        return this;
    }

    public PatientBuilder cough() {
        patient.setCough(true);
        return this;
    }

    public PatientBuilder noCough() {
        patient.setCough(false);
        return this;
    }

    public PatientBuilder nausea() {
        patient.setNausea(true);
        return this;
    }

    public PatientBuilder noNausea() {
        patient.setNausea(false);
        return this   ;
    }

    public Patient getResult() {
        return patient;
    }
}
