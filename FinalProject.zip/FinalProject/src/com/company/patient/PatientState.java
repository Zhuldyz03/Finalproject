package com.company.patient;

public abstract class PatientState {
    protected Patient patient;

    public PatientState(Patient patient) {
        this.patient = patient;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public abstract void giveParacetamol();
    public abstract void giveHotDrink();
}
