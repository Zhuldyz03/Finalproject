package com.company.patient;

public class PatientHypothermiaState extends PatientState {
    public PatientHypothermiaState(Patient patient) {
        super(patient);
    }

    @Override
    public void giveParacetamol() {
        patient.setTemperature(patient.getTemperature() - 1);
        System.out.println("Temperature decreased to 1");
    }

    @Override
    public void giveHotDrink() {
        patient.setTemperature(patient.getTemperature() + 1);
        System.out.println("Temperature increased to 1");
    }
}
