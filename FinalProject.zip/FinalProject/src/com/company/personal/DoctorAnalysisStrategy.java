package com.company.personal;

public class DoctorAnalysisStrategy implements DoctorStrategy {
    @Override
    public void curePatient() {
        System.out.println("Doctor did analysis of patient");
    }
}
