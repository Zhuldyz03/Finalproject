package com.company.personal;

public interface Personal {
    void doWork();
}
