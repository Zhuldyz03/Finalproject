package com.company.personal;

public interface PersonalFactory {
    Personal createPersonal();
}
