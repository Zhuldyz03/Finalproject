package com.company.personal;

public class DoctorPillsStrategy implements DoctorStrategy {
    @Override
    public void curePatient() {
        System.out.println("Doctor gave pills for patient");
    }
}
