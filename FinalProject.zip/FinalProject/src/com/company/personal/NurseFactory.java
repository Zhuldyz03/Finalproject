package com.company.personal;

public class NurseFactory implements PersonalFactory {
    @Override
    public Personal createPersonal() {
        return new Nurse();
    }
}
