package com.company.personal;

import javax.print.Doc;

public class Doctor implements Personal {
    private int id;
    private String fullname;
    private String specialization;
    private int salary;
    private DoctorStrategy doctorStrategy;

    public Doctor() {
    }

    public void fill(int id, String fullname, String specialization, int salary, DoctorStrategy doctorStrategy) {
        this.id = id;
        this.fullname = fullname;
        this.specialization = specialization;
        this.salary = salary;
        this.doctorStrategy = doctorStrategy;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public DoctorStrategy getDoctorStrategy() {
        return doctorStrategy;
    }

    public void setDoctorStrategy(DoctorStrategy doctorStrategy) {
        this.doctorStrategy = doctorStrategy;
    }

    public void cure() {
        doctorStrategy.curePatient();
    }

    @Override
    public void doWork() {
        System.out.println("Doctor " + fullname + " is doing his " + specialization + " work!");
    }
}
