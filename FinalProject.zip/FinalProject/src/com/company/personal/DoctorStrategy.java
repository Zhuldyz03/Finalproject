package com.company.personal;

public interface DoctorStrategy {
    void curePatient();
}
