package com.company.personal;

public class DoctorSurgeryStrategy implements DoctorStrategy {
    @Override
    public void curePatient() {
        System.out.println("Doctor is used surgery on patient");
    }
}
