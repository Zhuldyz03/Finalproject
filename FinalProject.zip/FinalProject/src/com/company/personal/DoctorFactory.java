package com.company.personal;

public class DoctorFactory implements PersonalFactory {
    @Override
    public Personal createPersonal() {
        return new Doctor();
    }
}
