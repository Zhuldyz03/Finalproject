package com.company.personal;

public class Nurse implements Personal {
    private int id;
    private String fullname;
    int salary;

    public Nurse() {
    }

    public Nurse(int id, String fullname, int salary) {
        this.id = id;
        this.fullname = fullname;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    @Override
    public void doWork() {
        System.out.println(fullname + " is doing nursing job");
    }
}
