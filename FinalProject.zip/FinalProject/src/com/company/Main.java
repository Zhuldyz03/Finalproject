package com.company;

import com.company.hospital.Hospital;
import com.company.hospital.HospitalController;
import com.company.hospital.HospitalObserver;
import com.company.patient.Patient;
import com.company.patient.PatientBuilder;
import com.company.personal.*;

public class Main {

    public static void main(String[] args) {
        DoctorFactory doctorFactory = new DoctorFactory();
        NurseFactory nurseFactory = new NurseFactory();

        DoctorPillsStrategy doctorPillsStrategy = new DoctorPillsStrategy();
        DoctorSurgeryStrategy doctorSurgeryStrategy = new DoctorSurgeryStrategy();
        Doctor d1 = (Doctor) doctorFactory.createPersonal();
        d1.fill(3, "Zhuldyz Bauyrzhanova", "Okulist", 150000, doctorPillsStrategy);
        Doctor d2 = (Doctor) doctorFactory.createPersonal();
        d2.fill(2, "Assanali Rysbek", "Animeist", 200000, doctorSurgeryStrategy);

        Hospital hospital = new Hospital();
        String[] types = {"ROOM1", "ROOM2"};
        HospitalObserver hospitalObserver = new Hospital(types);
        hospitalObserver.hire("ROOM1", d1);
        hospitalObserver.hire("ROOM2", d2);

        hospitalObserver.alert("ROOM1");
        HospitalController hospitalController = new HospitalController(hospital);
        HospitalController.alertAll(hospitalObserver);

        d1.cure();
        d2.cure();

        Patient patient = new PatientBuilder()
                .setId(3)
                .setFullName("Dayana Abiweva")
                .cough()
                .setAge(18)
                .setTemperature(37)
                .setPressureSystolic(130)
                .setPressureDiastolic(90)
                .getResult();

        System.out.println("Temperature was: " + patient.getTemperature());
        patient.giveParacetamol();
        System.out.println("Temperature became: " + patient.getTemperature());
    }
}
